import React, { useEffect } from 'react';
import { useCartStore } from '../store/cartStore';
import { CheckCircle } from 'lucide-react';

export function Success() {
  const clearCart = useCartStore((state) => state.clearCart);

  useEffect(() => {
    clearCart();
  }, [clearCart]);

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="bg-white p-8 rounded-lg shadow-md max-w-md w-full text-center">
        <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
        <h1 className="text-2xl font-semibold mb-4">Payment Successful!</h1>
        <p className="text-gray-600 mb-6">
          Thank you for your purchase. Your order has been confirmed and will be processed shortly.
        </p>
        <a
          href="/"
          className="bg-amber-600 text-white px-6 py-2 rounded-full hover:bg-amber-700 inline-block"
        >
          Continue Shopping
        </a>
      </div>
    </div>
  );
}