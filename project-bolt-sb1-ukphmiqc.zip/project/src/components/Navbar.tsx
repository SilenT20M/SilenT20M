import React, { useState } from 'react';
import { Flame, ShoppingCart, Menu, X } from 'lucide-react';
import { useCartStore } from '../store/cartStore';
import { Cart } from './Cart';

export function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const items = useCartStore((state) => state.items);

  return (
    <>
      <nav className="bg-primary text-secondary shadow-lg fixed w-full z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center group">
              <Flame className="h-8 w-8 text-secondary group-hover:scale-110 transition-transform" />
              <span className="ml-2 text-xl font-serif">Matrika</span>
            </div>
            
            <div className="hidden md:flex items-center space-x-8">
              {['Home', 'Products', 'About', 'Contact'].map((item) => (
                <a
                  key={item}
                  href={item === 'Home' ? '#' : `#${item.toLowerCase()}`}
                  className="text-secondary-light hover:text-secondary relative group"
                >
                  {item}
                  <span className="absolute bottom-0 left-0 w-full h-0.5 bg-secondary transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left"></span>
                </a>
              ))}
            </div>

            <div className="flex items-center space-x-4">
              <button 
                className="p-2 hover:bg-primary-light rounded-full transition-colors relative group"
                onClick={() => setIsCartOpen(true)}
              >
                <ShoppingCart className="h-6 w-6 text-secondary group-hover:text-secondary-light" />
                {items.length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-secondary text-primary text-xs rounded-full w-4 h-4 flex items-center justify-center">
                    {items.length}
                  </span>
                )}
              </button>
              <button 
                className="md:hidden p-2 hover:bg-primary-light rounded-full transition-colors"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? (
                  <X className="h-6 w-6 text-secondary" />
                ) : (
                  <Menu className="h-6 w-6 text-secondary" />
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-primary-light border-t border-primary-dark">
            <div className="px-2 pt-2 pb-3 space-y-1">
              {['Home', 'Products', 'About', 'Contact'].map((item) => (
                <a
                  key={item}
                  href={item === 'Home' ? '#' : `#${item.toLowerCase()}`}
                  className="block px-3 py-2 text-secondary hover:text-secondary-light hover:bg-primary transition-colors rounded-md"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item}
                </a>
              ))}
            </div>
          </div>
        )}
      </nav>

      <Cart isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
    </>
  );
}