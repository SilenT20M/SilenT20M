import React from 'react';
import { ChevronDown } from 'lucide-react';

export function Hero() {
  const scrollToProducts = () => {
    document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="relative h-screen">
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1603006905003-be475563bc59?auto=format&fit=crop&q=80"
          alt="Matrika Candles"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-primary/80 to-primary/60"></div>
      </div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
        <div className="text-secondary">
          <h1 className="text-6xl font-serif mb-4 animate-fade-in">
            Matrika Candles<br />
            <span className="text-secondary-light">Illuminate Your Spirit</span>
          </h1>
          <p className="text-xl mb-8 max-w-2xl animate-fade-in-delay text-secondary-light">
            Handcrafted with sacred intention, our artisanal candles blend ancient wisdom 
            with modern luxury to create moments of pure tranquility.
          </p>
          <button 
            className="bg-secondary text-primary px-8 py-3 rounded-full hover:bg-secondary-light 
                     transform hover:scale-105 transition-all duration-300 shadow-lg 
                     hover:shadow-secondary/30 animate-fade-in-delay-2"
          >
            Explore Collection
          </button>
        </div>
      </div>

      <button 
        onClick={scrollToProducts}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-secondary 
                 animate-bounce hover:text-secondary-light transition-colors"
      >
        <ChevronDown className="h-8 w-8" />
      </button>
    </div>
  );
}