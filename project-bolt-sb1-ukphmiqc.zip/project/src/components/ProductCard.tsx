import React, { useState } from 'react';
import { ShoppingCart, Heart } from 'lucide-react';
import { useCartStore } from '../store/cartStore';
import { Product } from '../types';

export function ProductCard({ 
  id,
  name, 
  price, 
  image, 
  description, 
  ingredients, 
  burnTime, 
  weight 
}: Product) {
  const [isHovered, setIsHovered] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);
  const addItem = useCartStore((state) => state.addItem);

  const handleAddToCart = () => {
    addItem({ id, name, price, image, description, ingredients, burnTime, weight });
  };

  return (
    <div 
      className="bg-secondary rounded-lg shadow-md overflow-hidden group relative"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative overflow-hidden">
        <img 
          src={image} 
          alt={name} 
          className="w-full h-64 object-cover transform group-hover:scale-110 transition-transform duration-700" 
        />
        <div className="absolute top-4 right-4">
          <button 
            onClick={() => setIsFavorite(!isFavorite)}
            className="p-2 bg-secondary rounded-full shadow-md hover:bg-secondary-light transition-colors"
          >
            <Heart 
              className={`h-5 w-5 ${isFavorite ? 'text-red-500 fill-current' : 'text-primary'}`} 
            />
          </button>
        </div>
      </div>

      <div className="p-6">
        <h3 className="text-xl font-serif mb-2 text-primary group-hover:text-primary-light transition-colors">
          {name}
        </h3>
        <p className="text-primary-light mb-4">{description}</p>
        
        <div className={`space-y-2 overflow-hidden transition-all duration-300 ${
          isHovered ? 'max-h-40 opacity-100 mb-4' : 'max-h-0 opacity-0'
        }`}>
          <div className="text-sm text-primary-light">
            <span className="font-medium">Burn Time:</span> {burnTime}
          </div>
          <div className="text-sm text-primary-light">
            <span className="font-medium">Weight:</span> {weight}
          </div>
          <div className="text-sm text-primary-light">
            <span className="font-medium">Ingredients:</span>
            <ul className="list-disc list-inside">
              {ingredients.map((ingredient, index) => (
                <li key={index}>{ingredient}</li>
              ))}
            </ul>
          </div>
        </div>

        <div className="flex justify-between items-center">
          <span className="text-xl font-bold text-primary">${price.toFixed(2)}</span>
          <button 
            onClick={handleAddToCart}
            className="bg-primary text-secondary px-6 py-2 rounded-full hover:bg-primary-light 
                     transform hover:scale-105 transition-all duration-300 flex items-center space-x-2"
          >
            <ShoppingCart className="h-4 w-4" />
            <span>Add to Cart</span>
          </button>
        </div>
      </div>
    </div>
  );
}