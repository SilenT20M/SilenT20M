import React from 'react';

export function About() {
  return (
    <section id="about" className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <img
              src="https://images.unsplash.com/photo-1599682914220-7ecd6c38f1f0?auto=format&fit=crop&q=80"
              alt="Candle making process"
              className="rounded-lg shadow-lg"
            />
          </div>
          <div>
            <h2 className="text-3xl font-serif mb-6">Crafted with Love</h2>
            <p className="text-gray-600 mb-6">
              At Luminous, we believe in creating more than just candles – we craft experiences. Each candle is handmade 
              with carefully selected natural ingredients, premium soy wax, and essential oils to bring warmth and 
              tranquility to your space.
            </p>
            <p className="text-gray-600 mb-6">
              Our passion for artisanal candle-making drives us to explore unique scent combinations while maintaining 
              our commitment to sustainable and eco-friendly practices.
            </p>
            <button className="bg-amber-600 text-white px-6 py-3 rounded-full hover:bg-amber-700 transition-colors">
              Learn More
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}