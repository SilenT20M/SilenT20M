import React, { useState } from 'react';
import { ProductCard } from './ProductCard';
import { ChevronLeft, ChevronRight } from 'lucide-react';

// Extended product data
const allProducts = Array.from({ length: 20 }, (_, i) => ({
  id: `product-${i + 1}`,
  name: [
    "Sacred Lavender Dreams",
    "Mystic Vanilla & Amber",
    "Ocean Meditation",
    "Forest Temple",
    "Mountain Sage",
    "Desert Rose",
    "Celestial Night",
    "Morning Dew"
  ][i % 8],
  price: 29.99 + (i * 2),
  image: [
    "https://images.unsplash.com/photo-1602874801007-bd36c376cd53",
    "https://images.unsplash.com/photo-1608181831718-c9ffd8728e95",
    "https://images.unsplash.com/photo-1596433809252-901acb55fc63",
    "https://images.unsplash.com/photo-1593642532744-d377ab507dc8",
    "https://images.unsplash.com/photo-1603006905003-be475563bc59",
    "https://images.unsplash.com/photo-1599682914220-7ecd6c38f1f0",
    "https://images.unsplash.com/photo-1595981267035-7b04ca84a82d",
    "https://images.unsplash.com/photo-1605651202774-7d573fd3f12d"
  ][i % 8] + "?auto=format&fit=crop&q=80",
  description: "A unique blend of natural ingredients for a peaceful atmosphere.",
  ingredients: ["Organic Soy Wax", "Essential Oils", "Cotton Wick", "Crystal Infusion"],
  burnTime: "40-45 hours",
  weight: "8 oz"
}));

const ITEMS_PER_PAGE = 8;

export function Products() {
  const [currentPage, setCurrentPage] = useState(1);
  const totalPages = Math.ceil(allProducts.length / ITEMS_PER_PAGE);
  
  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
  const endIndex = startIndex + ITEMS_PER_PAGE;
  const currentProducts = allProducts.slice(startIndex, endIndex);

  return (
    <section id="products" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-serif mb-4">Sacred Collection</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Each candle is handcrafted with intention, infused with crystal energy, 
            and made from premium organic ingredients to enhance your sacred space.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {currentProducts.map((product) => (
            <ProductCard key={product.id} {...product} />
          ))}
        </div>

        {/* Pagination */}
        <div className="mt-12 flex justify-center items-center space-x-4">
          <button
            onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="p-2 rounded-full hover:bg-amber-100 disabled:opacity-50 disabled:hover:bg-transparent"
          >
            <ChevronLeft className="h-6 w-6" />
          </button>
          
          <div className="flex items-center space-x-2">
            {Array.from({ length: totalPages }, (_, i) => (
              <button
                key={i + 1}
                onClick={() => setCurrentPage(i + 1)}
                className={`w-8 h-8 rounded-full ${
                  currentPage === i + 1
                    ? 'bg-amber-600 text-white'
                    : 'hover:bg-amber-100'
                }`}
              >
                {i + 1}
              </button>
            ))}
          </div>

          <button
            onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="p-2 rounded-full hover:bg-amber-100 disabled:opacity-50 disabled:hover:bg-transparent"
          >
            <ChevronRight className="h-6 w-6" />
          </button>
        </div>
      </div>
    </section>
  );
}