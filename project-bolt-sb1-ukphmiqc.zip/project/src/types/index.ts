export interface Product {
  id: string;
  name: string;
  price: number;
  image: string;
  description: string;
  ingredients: string[];
  burnTime: string;
  weight: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}